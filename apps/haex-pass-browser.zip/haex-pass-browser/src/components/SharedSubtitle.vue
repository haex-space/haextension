<template>
  <p class="mt-2 opacity-50">
    This is the {{ $app.context }} page
  </p>
</template>
