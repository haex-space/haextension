<script setup lang="ts">
// Content script overlay - currently empty as we handle UI in vanilla JS
// This can be extended for more complex overlay UIs if needed
</script>

<template>
  <div />
</template>
