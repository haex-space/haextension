import { describe, expect, it } from 'vitest'

describe('demo', () => {
  it('should work', () => {
    expect(1 + 1).toBe(2)
  })
})
